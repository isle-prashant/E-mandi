package com.twosquares.e_mandi;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SellingActivity extends AppCompatActivity {

    TextView image_name_tv;
    Button btpic, btnup;
    ImageView iv;
    int img = 0;
    Uri m;
    static String encodedImage;
    static String filePath;
    static String ip;

    private final OkHttpClient client = new OkHttpClient();

    public static String URL = "Paste your URL here";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selling);

        ip = getString(R.string.ip);
        System.out.println(ip);
        image_name_tv = (TextView) findViewById(R.id.tv);
        iv = (ImageView) findViewById(R.id.Imageprev);

        btpic = (Button) findViewById(R.id.click);
        btpic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Photoclickink();
            }
        });

        btnup = (Button) findViewById(R.id.pick);
        btnup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, 1);
            }
        });
    }



    public String getPath(Uri uri) {
        String[] projection = {MediaStore.MediaColumns.DATA};
        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor
                .getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        cursor.moveToFirst();
        String imagePath = cursor.getString(column_index);
        image_name_tv.setText(imagePath);
        return cursor.getString(column_index);
    }


    public File createTemporaryFile(String part, String ext) throws Exception {
        File tempDir = Environment.getExternalStorageDirectory();
        tempDir = new File(tempDir.getAbsolutePath() + "/.temp");
        if (!tempDir.exists())
            tempDir.mkdir();
        return File.createTempFile(part, ext, tempDir);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //To click an image
        if (requestCode == 0) {
            if (resultCode == RESULT_OK) {

                grabimage(m, iv);

            }
        }
        //To pick an image
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK) {
                Uri selectedImage = data.getData();

                filePath = getPath(selectedImage);
                String file_extn = filePath.substring(filePath.lastIndexOf(".") + 1);
                image_name_tv.setText(filePath);

                if (file_extn.equals("img") || file_extn.equals("jpg") || file_extn.equals("jpeg") || file_extn.equals("gif") || file_extn.equals("png")) {
                    //FINE
                    grabimage(selectedImage, iv);
                } else {
                    //NOT IN REQUIRED FORMAT
                    Toast.makeText(this, "Cannot Open the file", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    static Bitmap bitmap;
    public void grabimage(Uri uri, ImageView imageView) {
        if (uri != null) {


            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                ByteArrayOutputStream bao = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bao);
                byte[] b = bao.toByteArray();

                encodedImage = Base64.encodeToString(b, Base64.DEFAULT);

                imageView.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            new UploadImage().execute("https://api.imgur.com/3/image");
            System.out.println("calling");

        } else
            Toast.makeText(this, "Something went Wrong. Please try Again", Toast.LENGTH_SHORT).show();


    }


    public void Photoclickink() {
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File photo = Environment.getExternalStorageDirectory();
        getCacheDir();
        try {
            photo = this.createTemporaryFile("picture", ".jpg");

        } catch (Exception e) {
            e.printStackTrace();
        }

        if (photo != null)
            m = Uri.fromFile(photo);
        i.putExtra(MediaStore.EXTRA_OUTPUT, m);
        startActivityForResult(i, img);
        photo.delete();
    }



    public static class UploadImage extends AsyncTask<String, Void, Void> {

        private static final String IMGUR_CLIENT_ID = "9d04c2f5d9869a7";
        private static final MediaType MEDIA_TYPE_PNG = MediaType.parse("image/png");
        public static final MediaType MEDIA_TYPE_MARKDOWN
                = MediaType.parse("text/x-markdown; charset=utf-8");

        private final OkHttpClient client = new OkHttpClient();
        JSONObject jsonObject;
        @Override
        protected Void doInBackground(String... params) {

            System.out.println("here");
            // Use the imgur image upload API as documented at https://api.imgur.com/endpoints/image
            RequestBody requestBody = new FormBody.Builder()
                    .add("image", encodedImage)
                    .build();


            Request request = new Request.Builder()
                    .header("Authorization", "Client-ID " + IMGUR_CLIENT_ID)
                    .url("https://api.imgur.com/3/image")
                    .post(requestBody)
                    .build();

            Response response = null;
            String image_id = null;
            try {
                response = client.newCall(request).execute();
                if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

//                System.out.println(response.body().string());
                String res = response.body().string();
                System.out.println(res);
                jsonObject = new JSONObject(res);

                jsonObject = jsonObject.getJSONObject("data");
                image_id = jsonObject.getString("id");
                System.out.println(image_id);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            requestBody = new FormBody.Builder()
                    .add("id", image_id)
                    .build();


            request = new Request.Builder()
                    .url("http://"+ip+"/E-mandi/image.php")
                    .post(requestBody)
                    .build();

            try {
                response = client.newCall(request).execute();
                if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);
                System.out.println(response.body().string());
            } catch (IOException e) {
                e.printStackTrace();
            }



            return null;
        }
    }


}
