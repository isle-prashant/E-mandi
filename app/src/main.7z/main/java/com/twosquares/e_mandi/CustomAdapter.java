package com.twosquares.e_mandi;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by PRASHANT on 15-11-2016.
 */

public class CustomAdapter extends ArrayAdapter {
    Context context;
    List rowItem;
    public CustomAdapter(Context context, int resource, List objects) {
        super(context, R.layout.list_item, objects);
        this.context = context;
        rowItem = objects;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        convertView = inflater.inflate(R.layout.list_item,null);
        ImageView imageView = (ImageView) convertView.findViewById(R.id.imgThumbnail);
        TextView tv = (TextView) convertView.findViewById(R.id.txt);
        Picasso.with(context).load("http://i.imgur.com/" + rowItem.get(position) + "s.jpg").into(imageView);
        return convertView;
    }
}
